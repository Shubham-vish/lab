#include "ns3/core-module.h"
#include "ns3/applications-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/internet-module.h"
#include<vector>
using namespace ns3;
using namespace std;

NS_LOG_COMPONENT_DEFINE("My");

int main(){
	Time::SetResolution (Time::NS);
  LogComponentEnable ("UdpEchoClientApplication", LOG_LEVEL_INFO);
  LogComponentEnable ("UdpEchoServerApplication", LOG_LEVEL_INFO);

  NodeContainer nodes;
  nodes.Create (4);

  PointToPointHelper pointToPoint;
  pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("5Mbps"));
  pointToPoint.SetChannelAttribute ("Delay", StringValue ("2ms"));

  vector<NetDeviceContainer> devices;
	for(int i=0;i<4;++i){
		for(int j=i+1;j<4;++j){
			devices.push_back(pointToPoint.Install (nodes.Get(i), nodes.Get(j)));
		}
	}

  InternetStackHelper stack;
  stack.Install (nodes);

  Ipv4AddressHelper address;
  address.SetBase ("100.1.1.0", "255.255.255.0");

	vector<Ipv4InterfaceContainer> interfaces;
	for(auto d: devices) interfaces.push_back(address.Assign(d));

  UdpEchoServerHelper echoServer (9);

  ApplicationContainer serverApps=echoServer.Install(nodes.Get (0));
	serverApps.Start (Seconds (1.0)); 
	serverApps.Stop (Seconds (100.0));

  UdpEchoClientHelper echoClient (interfaces[0].GetAddress(0), 9);
  echoClient.SetAttribute ("MaxPackets", UintegerValue (1));
  echoClient.SetAttribute ("Interval", TimeValue (Seconds (0.5)));
  echoClient.SetAttribute ("PacketSize", UintegerValue (1024));

  ApplicationContainer clientApps[3];
	for(int i=0;i<3;++i) {
		clientApps[i] = echoClient.Install (nodes.Get (i+1));
		clientApps[i].Start(Seconds(2*i+1.0));
  	clientApps[i].Stop (Seconds (100.0));
	}

  Simulator::Run ();
  Simulator::Destroy ();
  return 0;

}
