 /* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
 /*
  * Copyright (c) 2010
  *
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License version 2 as
  * published by the Free Software Foundation;
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  *
  * Author: Nicola Baldo <nbaldo@cttc.es>
  */
 
 #ifndef ALOHA_NOACK_NET_DEVICE_H
 #define ALOHA_NOACK_NET_DEVICE_H
 
 #include <cstring>
 #include <ns3/node.h>
 #include <ns3/address.h>
 #include <ns3/net-device.h>
 #include <ns3/callback.h>
 #include <ns3/packet.h>
 #include <ns3/traced-callback.h>
 #include <ns3/nstime.h>
 #include <ns3/ptr.h>
 #include <ns3/mac48-address.h>
 #include <ns3/generic-phy.h>
 
 namespace ns3 {
 
 
 class SpectrumChannel;
 class Channel;
 class SpectrumErrorModel;
 template <typename Item> class Queue;
 
 
 
 class AlohaNoackNetDevice : public NetDevice
 {
 public:
   enum State
   {
     IDLE, 
     TX,   
     RX    
   };
 
   static TypeId GetTypeId (void);
 
   AlohaNoackNetDevice ();
   virtual ~AlohaNoackNetDevice ();
 
 
   virtual void SetQueue (Ptr<Queue<Packet> > queue);
 
 
   void NotifyTransmissionEnd (Ptr<const Packet>);
 
   void NotifyReceptionStart ();
 
 
   void NotifyReceptionEndError ();
 
   void NotifyReceptionEndOk (Ptr<Packet> p);
 
 
   void SetChannel (Ptr<Channel> c);
 
 
   void SetGenericPhyTxStartCallback (GenericPhyTxStartCallback c);
 
 
 
   void SetPhy (Ptr<Object> phy);
 
   Ptr<Object> GetPhy () const;
 
 
 
   // inherited from NetDevice
   virtual void SetIfIndex (const uint32_t index);
   virtual uint32_t GetIfIndex (void) const;
   virtual Ptr<Channel> GetChannel (void) const;
   virtual bool SetMtu (const uint16_t mtu);
   virtual uint16_t GetMtu (void) const;
   virtual void SetAddress (Address address);
   virtual Address GetAddress (void) const;
   virtual bool IsLinkUp (void) const;
   virtual void AddLinkChangeCallback (Callback<void> callback);
   virtual bool IsBroadcast (void) const;
   virtual Address GetBroadcast (void) const;
   virtual bool IsMulticast (void) const;
   virtual bool IsPointToPoint (void) const;
   virtual bool IsBridge (void) const;
   virtual bool Send (Ptr<Packet> packet, const Address& dest,
                      uint16_t protocolNumber);
   virtual bool SendFrom (Ptr<Packet> packet, const Address& source, const Address& dest,
                          uint16_t protocolNumber);
   virtual Ptr<Node> GetNode (void) const;
   virtual void SetNode (Ptr<Node> node);
   virtual bool NeedsArp (void) const;
   virtual void SetReceiveCallback (NetDevice::ReceiveCallback cb);
   virtual Address GetMulticast (Ipv4Address addr) const;
   virtual Address GetMulticast (Ipv6Address addr) const;
   virtual void SetPromiscReceiveCallback (PromiscReceiveCallback cb);
   virtual bool SupportsSendFrom (void) const;
 
 private:
   void NotifyGuardIntervalEnd ();
   virtual void DoDispose (void);
 
   void StartTransmission ();
 
 
   Ptr<Queue<Packet> > m_queue; 
 
   TracedCallback<Ptr<const Packet> > m_macTxTrace;        
   TracedCallback<Ptr<const Packet> > m_macTxDropTrace;    
   TracedCallback<Ptr<const Packet> > m_macPromiscRxTrace; 
   TracedCallback<Ptr<const Packet> > m_macRxTrace;        
 
   Ptr<Node>    m_node;    
   Ptr<Channel> m_channel; 
 
   Mac48Address m_address; 
 
   NetDevice::ReceiveCallback m_rxCallback;                
   NetDevice::PromiscReceiveCallback m_promiscRxCallback;  
 
   GenericPhyTxStartCallback m_phyMacTxStartCallback;      
 
   TracedCallback<> m_linkChangeCallbacks;
 
 
   uint32_t m_ifIndex;     
   mutable uint32_t m_mtu; 
   bool m_linkUp;          
 
   State m_state;          
   Ptr<Packet> m_currentPkt;  
   Ptr<Object> m_phy;      
 };
 
 
 } // namespace ns3
 
 #endif /* ALOHA_NOACK_NET_DEVICE_H */
