#include<arpa/inet.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<string.h>
#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>

int main(){
	int sock=socket(AF_INET, SOCK_STREAM,0);
	struct sockaddr_in client;
	memset(&client, 0, sizeof(client));
	client.sin_family=AF_INET;
	client.sin_port=htons(55000);
	client.sin_addr.s_addr=inet_addr("127.0.0.2");

	connect(sock, (struct sockaddr *)&client, sizeof(client));

	char poly[]="11010011101100000", div[]="1011", poly1[]="11010011101100000";
	int sz=sizeof(poly)/sizeof(poly[0])-1;
	int i=0;
	for(i=0;i<=sz-4;++i){
		if(poly[i]=='0') continue;
		int j=0;
		for(j=0;j<4;++j) poly[j+i]=(poly[j+i]-'0')^(div[j]-'0')+'0';
	}
	send(sock, &sz, sizeof(sz),0);
	for(i=sz-3;i<=sz;++i) poly1[i]=poly[i];
	send(sock, poly1, sizeof(poly1),0);
	close(sock);
	exit(0);
}
