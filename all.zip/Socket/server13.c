#include<arpa/inet.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>

int main(){
	int csock, ssock;
	struct sockaddr_in client, server;
	memset(&server, 0, sizeof(server));
	memset(&client, 0, sizeof(client));
	ssock=socket(AF_INET, SOCK_STREAM, 0);
	server.sin_family=AF_INET; server.sin_addr.s_addr=inet_addr("127.0.0.2"); server.sin_port=htons(55000);

	bind(ssock,(struct sockaddr*)&server,sizeof(server));
	listen(ssock, 5);
	int len=sizeof(client);
	csock=accept(ssock,(struct sockaddr*)&client, &len);

	char poly[100], div[]="1011";
	int i,j,n;
	recv(csock, &n, sizeof(n), 0);
	recv(csock, poly, sizeof(poly),0);
	for(i=0;i<n-3;++i){
		if(poly[i]=='0') continue;
		for(j=0;j<4;++j) poly[j+i]=(poly[j+i]-'0')^(div[j]-'0')+'0';	
	}
	printf("Polynomial after division: %s\n", poly);
	int ct=0;
	for(i=0;i<n;++i) if(poly[i]=='0') ++ct;
	if(ct==n) printf("Good data.\n");
	else printf("Bad data.\n");

	close(ssock);
}
