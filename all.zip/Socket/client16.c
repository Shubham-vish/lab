#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>         
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>


void main(){
	int sock;      // client socket discriptor
	int a,b,c,i;
	unsigned int len;
	char ch[3]="ex";
	char ch1[3];
	char pass[100];
	int msg1=1;
	int msg2=1;
	int inp1;
	char inp2[100];
	char inp3[100];

	struct sockaddr_in client;
	if((sock=socket(AF_INET,SOCK_STREAM,0))==-1){  // client socket is created..
		perror("socket: ");
		exit(-1);
	}

	client.sin_family=AF_INET;
	client.sin_port=htons(10000);        // initializing  socket  parameters 
	client.sin_addr.s_addr=INADDR_ANY;
	//inet_addr("127.0.0.1");
	bzero(&client.sin_zero,0); //appending 8 byte zeroes to 'struct sockaddr_in', to make it equal in size with 'struct sockaddr'.. 


	len=sizeof(struct sockaddr_in);
	if((connect(sock,(struct sockaddr *)&client,len))==-1){  //conneting to client
		perror("connect: ");
		exit(-1);
	}
	while(1){
		printf("Enter Password:\n");
		scanf("%s",pass);

		send(sock,pass,sizeof(pass),0);       // sending data back to client...

		recv(sock,&inp1,sizeof(c),0);

		if(inp1==msg1){
			printf("Send message:\n");
			scanf("%s",inp2);
			send(sock,inp2,sizeof(inp2),0);
			printf("CLient:%s\n",inp2);
			recv(sock,inp3,sizeof(inp3),0);
			printf("Server:%s\n",inp3);
			printf("Do you want to exit:Press ex\n");
			scanf("%s",ch1);
		}
		else{
			printf("Enter the correct Password:\n");
			printf("Or do you want to exit,Press ex,else press any other char\n");
			scanf("%s",ch1);
		}

		if((i=strcmp(ch,ch1))==0){
			close(sock);
			exit(0);
		}

	}

}

