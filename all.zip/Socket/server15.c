#include<arpa/inet.h>
#include<sys/socket.h>
#include<stdio.h>
#include<netinet/in.h>
#include<string.h>
#include<unistd.h>
int ssock, csock;
void func();

void main(){
	int port=55000;
	struct sockaddr_in client, server;
	memset(&server, 0x00, sizeof(server));
	ssock=socket(AF_INET, SOCK_STREAM, 0);
	server.sin_family=AF_INET; server.sin_port=htons(port); 
	server.sin_addr.s_addr=inet_addr("127.0.0.2");
	int len=sizeof(client);
	bind(ssock, (struct sockaddr*) &server, sizeof(server));
	listen(ssock, 5);
	csock=accept(ssock,(struct sockaddr*) &client, &len);
	char file[100]; recv(csock, file, sizeof(file),0);
	FILE *cl=fopen(file, "r"), *down=fopen("upload.txt", "w");
	char c;
	printf("File name received: %s\n", file);
	while(fscanf(cl, " %c", &c)!=EOF){
		fprintf(down, "%c", c);
	}
	
	close(ssock);
}
